package com.example.clase25gatitosfragments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.clase25gatitosfragments.databinding.ActivityMainBinding
import com.example.clase25gatitosfragments.databinding.FragmentGatitosBinding

class MainActivity : AppCompatActivity(), GatitosFragment.GatitosListener {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadFragment(GatitosFragment())
    }

    private fun loadFragment(fragment:Fragment){
        val fragmentTransaction = supportFragmentManager.beginTransaction()
        fragmentTransaction.replace(binding.layoutFragmentContainer.id,fragment)
        fragmentTransaction.addToBackStack(null)
        fragmentTransaction.commit()
    }

    override fun onClickPhoto(url: String) {
        val detalleFragment = DetalleFragment.newInstance(url)
        loadFragment(detalleFragment)
    }


}