package com.example.clase25gatitosfragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.clase25gatitosfragments.databinding.FragmentDetalleBinding
import com.squareup.picasso.Picasso


private const val DETALLE_FRAGMENT_PHOTO = "com.example.clase25.gatitos.fragment.photo.url"


class DetalleFragment : Fragment() {
    private var url: String? = null

    private var _binding : FragmentDetalleBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            url = it.getString(DETALLE_FRAGMENT_PHOTO)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentDetalleBinding.inflate(inflater,container,false)
        loadImage()
        return binding.root
    }

    companion object {
        fun newInstance(url: String) =
            DetalleFragment().apply {
                arguments = Bundle().apply {
                    putString(DETALLE_FRAGMENT_PHOTO, url)
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun loadImage(){
        Picasso.get().load(url).into(binding.imgGatito)
    }
}